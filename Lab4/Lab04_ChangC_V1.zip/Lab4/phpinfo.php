<?php
  phpinfo();
  ?>
  